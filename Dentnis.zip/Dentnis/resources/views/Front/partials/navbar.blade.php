<div class="header">
    <ul class="container1">
        <div class="image">
            <img src="https://dentnis.com/wp-content/uploads/2022/06/dentnis-logo-2.svg" alt="logo">
        </div>
        <div>
            <ul class="navbar">
                <li>
                    <a href=""><span> Estetik Diş Hekimliği </span> </a>
                    <ul>
                        <li><a href=""> Guluş Tasarimi Nedir?</a></li>
                        <li><a href="">Zirkonyum Dis Kaplama</a></li>
                        <li><a href="">Laminate Veneer</a></li>
                        <li><a href="">Lamine Dis Kaplama</a></li>
                        <li><a href="">Pembe Estetik</a></li>
                        <li><a href="">Dis Beyazlatma</a></li>
                    </ul>
                </li>
                <li>
                    <a href=""><span>Konservativ Tedaviler</span></a>
                    <ul>
                        <li><a href=""> Guluş Tasarimi Nedir?</a></li>
                        <li><a href="">Zirkonyum Dis Kaplama</a></li>
                        <li><a href="">Laminate Veneer</a></li>
                        <li><a href="">Lamine Dis Kaplama</a></li>
                        <li><a href="">Pembe Estetik</a></li>
                        <li><a href="">Dis Beyazlatma</a></li>
                    </ul>
                </li>
                <li>
                    <a href=""> <span>Implant Tedavisi</span></a>
                    <ul>
                        <li><a href=""> Guluş Tasarimi Nedir?</a></li>
                        <li><a href="">Zirkonyum Dis Kaplama</a></li>
                        <li><a href="">Laminate Veneer</a></li>
                        <li><a href="">Lamine Dis Kaplama</a></li>
                        <li><a href="">Pembe Estetik</a></li>
                        <li><a href="">Dis Beyazlatma</a></li>
                    </ul>
                </li>
                <li>
                    <a href=""> <span>Hakkimizda</span></a>
                    <ul>
                        <li><a href=""> Guluş Tasarimi Nedir?</a></li>
                        <li><a href="">Zirkonyum Dis Kaplama</a></li>
                        <li><a href="">Laminate Veneer</a></li>
                        <li><a href="">Lamine Dis Kaplama</a></li>
                        <li><a href="">Pembe Estetik</a></li>
                        <li><a href="">Dis Beyazlatma</a></li>
                    </ul>
                </li>
                <li>
                    <a href=""> <span>Iletisim</span></a>
                </li>
                <a href="" class="lang"><img src="" alt="" id="en"></a>
                <a href="" class="lang"><img src="" alt="" id="gr"></a>
                <a href="" class="d-none lang"><img alt="" src="" id="tr"></a>
            </ul>
            <a href=""><i class="fa-solid fa-magnifying-glass"></i></a>
        </div>
    </ul>
</div>
