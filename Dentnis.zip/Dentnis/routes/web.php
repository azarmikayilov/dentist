<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[\App\Http\Controllers\Front\BlogController::class,'index']);
Route::get('/singlePage',[\App\Http\Controllers\Front\BlogController::class,'singlePage']);
Route::get('/about',[\App\Http\Controllers\Front\BlogController::class,'about']);
Route::get('/contact',[\App\Http\Controllers\Front\BlogController::class,'contact']);
Route::get('/article',[\App\Http\Controllers\Front\BlogController::class,'article']);
Route::get('/tv-programs',[\App\Http\Controllers\Front\BlogController::class,'tvPrograms']);
