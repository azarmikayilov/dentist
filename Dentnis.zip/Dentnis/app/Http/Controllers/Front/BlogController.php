<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\MenuBuilder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{
    public function index()
    {
//        $menus = Menu::leftJoin('pages', 'menus.page_id', '=', 'pages.id')
//            ->select('menus.*', 'pages.slug') // İhtiyacınıza göre seçimleri belirleyin
//            ->get();

//        dd($menus);
////
//        $menuList = Menu::where('is_active', 1)->orderBy('order_index','asc')->get();
//

//        $menuTree = MenuBuilder::buildMenuTree($menus);
//        echo '<pre>';
//        foreach ($menuTree as $item) {
//            echo $item->title.PHP_EOL;
//            if (count($item->children) > 0) {
//                foreach ($item->children as $i) {
//                    echo '<h1>'.$i->title.'</h1>'.PHP_EOL;
//                }
//            }
//        }
//        dd($menuTree);
        return view('Front.pages.main');


//        return view('welcome', compact('menuTree'));
//        return view('Front.pages.main', compact('menuTree'));
//        return view('Front.pages.main');
    }

    public function singlePage()
    {
        return view('Front.pages.singlePage');
    }

    public function about()
    {
        return view('Front.pages.about');
    }

    public function contact()
    {
        return view('Front.pages.contact');
    }

    public function tvPrograms()
    {
        return view('Front.pages.tv-programs');
    }

    public function article()
    {
        return view('Front.pages.articles');
    }
}
