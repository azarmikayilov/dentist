<footer class="footerMain">
    <div class="top-footer">
        <h2>Diş Estetiği ile ilgili sorunlarınız mı var?</h2>
        <a>Contact us</a>
    </div>
    <div class="bottom-footer">
        <div class="upper">
            <div class="logo-part">
                <img src="https://dentnis.com/wp-content/uploads/2023/02/dentnis-logo-white-1.png" alt="">
                <div class="address">
                    <p class="address-line">Adres: Valikonağı Caddesi, Narin Apartmanı</p>
                    <p class="phone-number">Telefon: +90 (212) 246 09 03</p>
                    <p class="email">Mail: info@dentnis.com</p>
                </div>
            </div>
            <div class="titles-part">
                <p><a href="" class="footer-li">Gülüş Tasarımı</a></p>
                <p><a href="" class="footer-li">Gülüş Tasarımı</a></p>
                <p><a href="" class="footer-li">Gülüş Tasarımı</a></p>
                <p><a href="" class="footer-li">Gülüş Tasarımı</a></p>
                <p><a href="" class="footer-li">Gülüş Tasarımı</a></p>
            </div>
        </div>
        <div class="lower">
            <p>© 2024 Tüm hakları www.dentnis.com’a aittir.</p>
            <p>Dentnis.com'da yer alan tüm içerikler sadece kullanıcıyı bilgilendirmek amacı ile sunulmuş olup tıbbi tedavi anlamında tavsiye niteliği taşımamaktadır.</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Shafa Zeynalli\Documents\FinalProject\Dentnis\resources\views/Front/partials/footer.blade.php ENDPATH**/ ?>