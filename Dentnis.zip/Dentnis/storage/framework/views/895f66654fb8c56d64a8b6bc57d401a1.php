<!DOCTYPE html>
<html lang="tr-TR" class="js_active vc_desktop vc_transform vc_transform js">

<?php echo $__env->make('Front.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body
    class="home page-template-default page page-id-521 wp-custom-logo color-custom style-default button-default layout-full-width one-page header-classic sticky-tb-color ab-hide subheader-both-center menu-link-color menuo-right mobile-tb-center mobile-side-slide mobile-mini-mr-ll be-2149 wpb-js-composer js-comp-ver-6.11.0 vc_responsive"
    style="left: 0px;">
<div id="Wrapper">
    <?php echo $__env->make('Front.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- mfn_hook_content_before --><!-- mfn_hook_content_before -->


    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('Front.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="Side_slide" class="right dark" data-width="500" style="right:-500px;">
        <div class="close-wrapper"><a href="#" class="close">
                <i class="icon-cancel-fine"></i></a></div>
        <div class="extras">
            <div class="extras-wrapper"><a class="icon search" href="#"><i
                        class="icon-search-fine"></i></a><a class="lang-active" href="#"><img
                        src="https://dentnis.com/wp-content/plugins/polylang/flags/tr.png"
                        alt="" width="18" height="12">
                    <i class="icon-down-open-mini"></i></a></div>
        </div>
        <div class="search-wrapper">
            <form id="side-form" method="get"
                  action="https://dentnis.com/">
                <input type="text" class="field" name="s"
                       placeholder="Aramanızı girin">
                <input type="submit"
                       class="display-none"
                       value="">
                <input type="hidden"
                       name="lang"
                       value="tr"><a
                    class="submit" href="#"><i class="icon-search-fine"></i></a></form>
        </div>
        <div class="lang-wrapper">
            <ul class="wpml-lang">
                <li><a href="https://dentnis.com/" class="active">
                        <img
                            src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2018%2012'%3E%3C/svg%3E"
                            alt="" width="18" height="12">
                    </a></li>
                <li><a href="https://dentnis.com/en/" class="">
                        <img
                            src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2018%2012'%3E%3C/svg%3E"
                            alt="" width="18" height="12">
                    </a></li>
                <li><a href="https://dentnis.com/de/" class="">
                        <img
                            src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2018%2012'%3E%3C/svg%3E"
                            alt="" width="18" height="12">
                    </a></li>
            </ul>
        </div>
        <div class="menu_wrapper"></div>
        <ul class="social"></ul>
    </div>
    <div id="body_overlay"></div>


    <div class="cli-modal" data-nosnippet="true" id="cliSettingsPopup" tabindex="-1"
         role="dialog" aria-labelledby="cliSettingsPopup" aria-hidden="true">
        <div class="cli-modal-dialog" role="document">
            <div class="cli-modal-content cli-bar-popup">
                <button type="button" class="cli-modal-close" id="cliModalClose">
                    <svg class="" viewBox="0 0 24 24">
                        <path
                            d="M19 6.41l-1.41-1.41-5.59 5.59-5.59-5.59-1.41 1.41 5.59 5.59-5.59 5.59 1.41 1.41 5.59-5.59  5.59 5.59 1.41-1.41-5.59-5.59z"></path>
                        <path d="M0 0h24v24h-24z"
                              fill="none"></path>
                    </svg>
                    <span class="wt-cli-sr-only">Close</span>
                </button>
                <div class="cli-modal-body">
                    <div class="cli-container-fluid cli-tab-container">
                        <div class="cli-row">
                            <div class="cli-col-12 cli-align-items-stretch cli-px-0">
                                <div class="cli-privacy-overview">
                                    <h4>Privacy Overview</h4>
                                    <div class="cli-privacy-content">
                                        <div class="cli-privacy-content-text">This website uses
                                            cookies to improve your experience while you navigate
                                            through the website. Out of these cookies, the cookies
                                            that are categorized as necessary are stored on your
                                            browser as they are essential for the working of basic
                                            functionalities...
                                        </div>
                                    </div>
                                    <a class="cli-privacy-readmore" aria-label="Show more"
                                       role="button" data-readmore-text="Show more"
                                       data-readless-text="Show less"></a></div>
                            </div>
                            <div class="cli-col-12 cli-align-items-stretch cli-px-0  cli-tab-section-container">
                                <div class="cli-tab-section">
                                    <div class="cli-tab-header">
                                        <a role="button" tabindex="0" class="cli-nav-link  cli-settings-mobile"
                                           data-target="necessary"
                                           data-toggle="cli-toggle-tab">
                                            Necessary </a>
                                        <div class="wt-cli-necessary-checkbox">
                                            <input type="checkbox"
                                                   class="cli-user-preference-checkbox"
                                                   id="wt-cli-checkbox-necessary"
                                                   data-id="checkbox-necessary" checked="checked">
                                            <label class="form-check-label"
                                                   for="wt-cli-checkbox-necessary">Necessary</label>
                                        </div>
                                        <span class="cli-necessary-caption">Always Enabled</span>
                                    </div>
                                    <div class="cli-tab-content">
                                        <div class="cli-tab-pane cli-fade" data-id="necessary">
                                            <div class="wt-cli-cookie-description">
                                                Necessary cookies are absolutely essential for the
                                                website to function properly. This category only
                                                includes cookies that ensures basic functionalities and
                                                security features of the website. These cookies do not
                                                store any personal information.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="cli-tab-section">
                                    <div class="cli-tab-header">
                                        <a role="button" tabindex="0" class="cli-nav-link cli-settings-mobile"
                                           data-target="non-necessary"
                                           data-toggle="cli-toggle-tab">
                                            Non-necessary </a>
                                        <div class="cli-switch">
                                            <input type="checkbox" id="wt-cli-checkbox-non-necessary"
                                                   class="cli-user-preference-checkbox"
                                                   data-id="checkbox-non-necessary" checked="checked">
                                            <label for="wt-cli-checkbox-non-necessary"
                                                   class="cli-slider" data-cli-enable="Enabled"
                                                   data-cli-disable="Disabled"><span
                                                    class="wt-cli-sr-only">Non-necessary</span></label>
                                        </div>
                                    </div>
                                    <div class="cli-tab-content">
                                        <div class="cli-tab-pane cli-fade" data-id="non-necessary">
                                            <div class="wt-cli-cookie-description">
                                                Any cookies that may not be particularly necessary for
                                                the website to function and is used specifically to
                                                collect user personal data via analytics, ads, other
                                                embedded contents are termed as non-necessary cookies.
                                                It is mandatory to procure user consent prior to running
                                                these cookies on your website.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cli-modal-footer">
                    <div class="wt-cli-element cli-container-fluid cli-tab-container">
                        <div class="cli-row">
                            <div class="cli-col-12 cli-align-items-stretch cli-px-0">
                                <div class="cli-tab-footer wt-cli-privacy-overview-actions">
                                    <a id="wt-cli-privacy-save-btn" role="button" tabindex="0"
                                       data-cli-action="accept"
                                       class="wt-cli-privacy-btn cli_setting_save_button wt-cli-privacy-accept-btn cli-btn">SAVE
                                        &amp; ACCEPT</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cli-modal-backdrop cli-fade cli-settings-overlay"></div>
    <div class="cli-modal-backdrop cli-fade cli-popupbar-overlay"></div>

    <?php echo $__env->make('Front.partials.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="fixed-social-media-icons">
        <ul>

            <li id="social-arrow-right" style="display: none;">
                <a href="#">
                    <img width="448" height="512"
                         src="/wp-content/uploads/2022/02/arrow-right-solid.svg" alt=""
                         aria-hidden="true">
                </a>
            </li>
            <li>
                <a href=""
                   target="_blank" rel="nofollow">
                    <img width="512" height="512"
                         src="<?php echo e(asset('assets/front/images/facebook.svg')); ?>" alt=""
                         data-lazy-src="/wp-content/uploads/2022/02/facebook-brands.svg"
                         data-ll-status="loaded" class="entered lazyloaded">
                </a>
            </li>
            <li class="icons-middle">
                <a href=""
                   target="_blank" rel="nofollow">
                    <img width="448" height="512"
                         src="<?php echo e(asset('assets/front/images/linkedin.svg')); ?>" alt="">
                </a>
            </li>
            <li>
                <a href="" target="_blank"
                   rel="nofollow">
                    <img width="448" height="512"
                         src="<?php echo e(asset('assets/front/images/instagram.svg')); ?>" alt="">
                </a>
            </li>
            <li class="icons-middle2">
                <a href=""
                   target="_blank" rel="nofollow">
                    <img width="576" height="512"
                         src="<?php echo e(asset('assets/front/images/youtube.svg')); ?>" alt="">
                </a>
            </li>
        </ul>
    </div>
    <div class="mobil-call-first"><a href="tel:+905337694469"><img
                src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2040%2040'%3E%3C/svg%3E"
                width="40" height="40"
                data-lazy-src="/wp-content/uploads/2020/12/phone-icon-1.svg">
        </a></div>
    <div class="open-socials" style="display: none;">
        <ul>
            <li id="social-arrow-left">
                <a href="#">
                    <img width="448" height="512"
                         src="/wp-content/uploads/2022/02/arrow-left-solid.svg" alt=""
                         aria-hidden="true"
                         data-lazy-src="/wp-content/uploads/2022/02/arrow-left-solid.svg"
                         data-ll-status="loaded" class="entered lazyloaded">
                    <noscript><img
                            width="448" height="512"
                            src="/wp-content/uploads/2022/02/arrow-left-solid.svg" alt=""
                            aria-hidden="true"></noscript>
                </a>
            </li>
        </ul>
    </div>
    <div class="zmt-mobile-buttons">

        <a class="zmt-mobile-buttons-left" id="whatsapp-button"
           href="https://api.whatsapp.com/send?phone=+905337694469&amp;text=Merhaba,%20tedavileriniz%20%20hakkında%20bilgi%20almak%20istiyorum">
      <span class="callMeIcon"><img width="448" height="512"
                                    src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20448%20512'%3E%3C/svg%3E"
                                    alt=""
                                    data-lazy-src="/wp-content/uploads/2022/02/whatsapp-brands.svg"><noscript><img
                  width="448" height="512"
                  src="/wp-content/uploads/2022/02/whatsapp-brands.svg" alt=""></noscript></span>
            <span class="callMeText">WhatsApp</span></a>

        <a class="zmt-mobile-buttons-right" id="call-button"
           href="https://dentnis.com/iletisim/">
      <span class="callMeIcon"><img width="448" height="448"
                                    src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20448%20448'%3E%3C/svg%3E"
                                    alt=""
                                    data-lazy-src="/wp-content/uploads/2023/03/contact-us-icon.svg"><noscript><img
                  width="448" height="448"
                  src="/wp-content/uploads/2023/03/contact-us-icon.svg" alt=""></noscript></span>
            <span class="callMeText">Mail</span></a>

    </div>
    <div class="mobil-map">
        <a
            href="https://www.google.com/maps/place/DentNis+%C4%B0mplantoloji+ve+Estetik+Di%C5%9F+Klini%C4%9Fi+(Dr.Abdulkadir+Narin)/@41.05546,28.995565,15z/data=!4m5!3m4!1s0x0:0x4c991533fbafe83a!8m2!3d41.05546!4d28.995565"><img
                src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2040%2040'%3E%3C/svg%3E"
                width="40" height="40"
                data-lazy-src="/wp-content/uploads/2021/01/mobile-map-icon-1.svg">
            <noscript><img
                    src="/wp-content/uploads/2021/01/mobile-map-icon-1.svg" width="40"
                    height="40"></noscript>
        </a>
    </div>
    <div class="mobil-map mobil-instagram">
        <a href="https://www.instagram.com/doktornarin/" target="_blank">
            <img src="./assets/instagram.svg"
                 width="40" height="40">
        </a>
    </div>
    <div id="sm-wrapper"></div>
</body>
</html>

<?php /**PATH C:\Users\Shafa Zeynalli\Documents\FinalProject\Dentnis\resources\views/Front/front.blade.php ENDPATH**/ ?>
