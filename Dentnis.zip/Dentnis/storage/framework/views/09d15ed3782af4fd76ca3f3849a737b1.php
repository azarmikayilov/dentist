<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('Front.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('Front.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('Front.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Front.partials.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="sosialMedia">
        <ul>
            <li><a href=""><img src="<?php echo e(asset('assets/front/images/facebook.svg')); ?>" alt=""></a></li>
            <li><a href=""><img src="<?php echo e(asset('assets/front/images/linkedin.svg')); ?>" alt=""></a></li>
            <li><a href=""><img src="<?php echo e(asset('assets/front/images/instagram.svg')); ?>" alt=""></a></li>
            <li><a href=""><img src="<?php echo e(asset('assets/front/images/youtube.svg')); ?>" alt=""></a></li>
        </ul>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/front/js/mainJs.js')); ?>"></script>
</body>
</html>

<?php /**PATH C:\Users\Shafa Zeynalli\Documents\FinalProject\Dentnis\resources\views/Front/Layouts/front.blade.php ENDPATH**/ ?>