<?php $__env->startSection('content'); ?>
    <div class="slider">
        <div id="image-container">
            <a href="#"><img src="https://dentnis.com/wp-content/uploads/2023/05/dentnis-ekip.webp" alt="Image 1"
                             class="active"></a>
            <a href="#"><img src="https://dentnis.com/wp-content/uploads/2022/07/1-gunde-implant-nasil-yapilir.png"
                             alt="Image 2"></a>
            <a href="#"><img src="https://dentnis.com/wp-content/uploads/2022/07/dis-beyazlatma-nasil-yapilir.jpg"
                             alt="Image 3"></a>
            <a href="#"><img src="https://dentnis.com/wp-content/uploads/2022/07/eniyidishekimi.jpg" alt="Image 4"></a>
        </div>
        <div class="buttons">

            <button id="prevBtn" onclick="prevImage()"><</button>
            <button id="nextBtn" onclick="nextImage()"> ></button>
        </div>
    </div>
    <div class="section1">
        <h1>Estetik Diş Hekimliği</h1>
        <div class="row">
            <div class="col">
                <img src="https://dentnis.com/wp-content/uploads/2019/12/gulus-tasarimi-image-1-e1577528252697.png" alt="">
                <p class="title">Gülüş tasarımı</p>
                <p> Güzel bir gülüş oluşturmaya yönelik sanatsal süreç kişiye özel gülüş tasarımı ile başlar. Gülüş tasarımı
                    için gerekli planlama ve alt yapı sağlandıktan sonra 1 hafta gibi kısa bir sürede de güzel bir gülüşe
                    sahip olmaktasınız.
                    Estetik Diş Hekimi Dt. Abdulkadir Narin</p>
            </div>
            <div class="col">
                <img src="https://dentnis.com/wp-content/uploads/2019/12/dis-beyazlatma-image-1-e1577528533942.png" alt="">
                <p class="title">Gülüş tasarımı</p>
                <p> Güzel bir gülüş oluşturmaya yönelik sanatsal süreç kişiye özel gülüş tasarımı ile başlar. Gülüş tasarımı
                    için gerekli planlama ve alt yapı sağlandıktan sonra 1 hafta gibi kısa bir sürede de güzel bir gülüşe
                    sahip olmaktasınız.
                    Estetik Diş Hekimi Dt. Abdulkadir Narin</p>
            </div>
            <div class="col">
                <img src="https://dentnis.com/wp-content/uploads/2019/12/bir-gunde-implant-image-e1577528759561.png" alt="">
                <p class="title">Gülüş tasarımı</p>
                <p> Güzel bir gülüş oluşturmaya yönelik sanatsal süreç kişiye özel gülüş tasarımı ile başlar. Gülüş tasarımı
                    için gerekli planlama ve alt yapı sağlandıktan sonra 1 hafta gibi kısa bir sürede de güzel bir gülüşe
                    sahip olmaktasınız.
                    Estetik Diş Hekimi Dt. Abdulkadir Narin</p>
            </div>
        </div>
    </div>
    <!-- sponsor slider start -->
    <div class="containerSponsor">
        <div class="swiper mySwiper my">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="ust-padding">
                        <div class="for-padding">
                            <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/megagen-1.png.webp">
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="ust-padding">
                        <div class="for-padding">
                            <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/saglik-bakanligi-1.png.webp">
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="ust-padding">
                        <div class="for-padding">
                            <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/straumann-1.png.webp">
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="ust-padding">
                        <div class="for-padding">
                            <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/nobel-1.png.webp">
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="ust-padding">
                        <div class="for-padding">
                            <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/thy-1.png.webp">
                        </div>
                    </div>
                </div>
                <!--            <div class="swiper-slide">-->
                <!--                <div class="ust-padding">-->
                <!--                    <div class="for-padding">-->
                <!--                        <img src="images1/megagen-1.png">-->
                <!--                    </div>-->
                <!--                </div>-->
                <!--            </div>-->
            </div>

            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <!-- sponsor slider end -->
    <!-- YouTube start-->
    <div class="youtube">
        <iframe width="918" height="450" src="https://www.youtube.com/embed/GkXLn7nbYxs"
                title="Dentnis İmplantoloji ve Estetik Diş Kliniği" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
    </div>
    <!-- YouTube end-->
    <!-- Ekibimiz start -->
    <div class="ekibimiz-container">
        <h1>Ekibimiz</h1>
        <div class="swiper-2 mySwiper my2">
            <div class="swiper-wrapper">
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>
                <div class="swiper-slide mz">
                    <div class="top-section">
                        <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2021/02/rabia-akca.jpg.webp" alt="...">
                    </div>
                    <div class="bottom-section">
                        <h3 class="doctor-name">
                            Dt. Musa Erdem
                        </h3>
                        <div class="ekibimiz-line"></div>
                        <h5 class="doctor-position">
                            Çene Cerrahisi ve Ortognatik Cerrahi
                        </h5>
                    </div>
                </div>


            </div>
        </div>

    </div>
    <!--Ekibimiz end-->
    <!--Estetik dis hekimligi start-->
    <div class="section2">
        <h2>Estetik Diş Hekimliği</h2>
        <div class="container1">
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/uploads/2023/05/gulus-tasarimi-1.png" alt="Image"
                     style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/05/bir-gunde-implant.png.webp"
                     alt="Image" style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/05/pembe-estetik.png.webp"
                     alt="Image" style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/05/implant-fiyatlari-image.png.webp"
                     alt="Image" style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/05/gulus-tasarimi-fiyatlari-image.png.webp"
                     alt="Image" style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
            <div class="image-container">
                <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/05/dis-dolgusu-fiyatlari-image.png.webp"
                     alt="Image" style="width: 100%; height: 100%;">
                <div class="image-overlay"></div>
                <div class="image-title">Gülüş tasarımı</div>
                <div class="underline"></div>
            </div>
        </div>
    </div>
    <!--Estetik dis hekimligi end-->
    <!--Article section start-->
    <div class="articles">
        <h2>Makaleler</h2>
        <div class="container1">
            <div class="col">
                <div class="image">
                    <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2024/01/Adsiz-tasarim-1.jpg.webp" alt="">
                </div>
                <div class="content">
                    <h2>Nişantaşı Gülüş Tasarımı (Gülüş Estetiği)</h2>
                    <p>Nişantaşı gülüş tasarımı diş estetiği ve kozmetik diş hekimliği adı altında yapılan bir tedaviler bütünüdür. Bu tedavi ile hasta gülüşündeki eksiklikleri, istemediği durumları, görünümünü ve dişin […]</p>
                    <button>Devamını oku</button>
                </div>
            </div>
            <div class="col">
                <div class="image">
                    <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/12/implant-omru-ne-kadar.jpg.webp" alt=""/>
                </div>
                <div class="content">
                    <h2>Nişantaşı Gülüş Tasarımı (Gülüş Estetiği)</h2>
                    <p>Nişantaşı gülüş tasarımı diş estetiği ve kozmetik diş hekimliği adı altında yapılan bir tedaviler bütünüdür. Bu tedavi ile hasta gülüşündeki eksiklikleri, istemediği durumları, görünümünü ve dişin […]</p>
                    <button>Devamını oku</button>
                </div>
            </div>
            <div class="col">
                <div class="image">
                    <img src="https://dentnis.com/wp-content/webp-express/webp-images/uploads/2023/11/kaplama-disim-dustu.jpg.webp" alt="">
                </div>
                <div class="content">
                    <h2>Nişantaşı Gülüş Tasarımı (Gülüş Estetiği)</h2>
                    <p>Nişantaşı gülüş tasarımı diş estetiği ve kozmetik diş hekimliği adı altında yapılan bir tedaviler bütünüdür. Bu tedavi ile hasta gülüşündeki eksiklikleri, istemediği durumları, görünümünü ve dişin […]</p>
                    <button>Devamını oku</button>
                </div>
            </div>
        </div>
    </div>
    <!--Article section end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front.Layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shafa Zeynalli\Documents\FinalProject\Dentnis\resources\views/Front/pages/main.blade.php ENDPATH**/ ?>