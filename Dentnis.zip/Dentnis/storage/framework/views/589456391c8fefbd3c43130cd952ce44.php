<ul>
    <?php $__currentLoopData = $menuTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($menuItem->title); ?>

            <b>Slug: <?php echo e($menuItem->slug); ?></b>
            <?php if(count($menuItem->children) > 0): ?>
                <ul>
                    <?php $__currentLoopData = $menuItem->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($submenu->title); ?>

                            <b>Slug: <?php echo e($submenu->slug); ?></b>



                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\Users\Shafa Zeynalli\Documents\FinalProject\Dentnis\resources\views/welcome.blade.php ENDPATH**/ ?>